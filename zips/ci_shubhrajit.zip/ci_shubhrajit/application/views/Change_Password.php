<!DOCTYPE html>
<html>
<head>
	<title>Password Change</title>
</head>
<body bgcolor="orange">
	<center>
		<h3>Password Change</h3>
<form method="POST">
	Old Password:<input type="password" name="old" ><br>
	New Password:<input type="password" name="new" ><br>
	Confirm Password:<input type="password" name="confirm" ><br><br>
	<input type="submit" name="submit" value="Update">
</form>
</center>
</body>
</html>
