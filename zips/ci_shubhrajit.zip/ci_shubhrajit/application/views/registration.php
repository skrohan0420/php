<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
</head>
<body bgcolor="orange">
<form method="post">
	Name:<input type="text" name="myname"><br>
	Email:<input type="text" name="myemail"><br>
	Mobile:<input type="text" name="mymobile"><br>
	Password:<input type="password" name="mypassword"><br>
	Address:<input type="text" name="myaddress"><br>
	<input type="submit" name="submit" value="Submit">
</form>
</body>
</html>