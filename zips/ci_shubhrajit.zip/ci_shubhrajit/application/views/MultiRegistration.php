<!DOCTYPE html>
<html>
<head>
	<title>Multi Registration</title>
</head>
<body bgcolor="orange">
<center>
	<h1 style="color:blue;">Complete Your Registration</h1>
	<hr>
	<form method="post">
		Name:<input type="text" name="myname"><br>
		Email:<input type="email" name="myemail"><br>
		Password:<input type="password" name="mypassword"><br>
		UserType:<input type="radio" name="user" value="Admin">Admin
			<input type="radio" name="user" value="User">User
		<br><br>
		<input type="submit" name="submit" value="Submit">
	</form>
</center>
</body>
</html>