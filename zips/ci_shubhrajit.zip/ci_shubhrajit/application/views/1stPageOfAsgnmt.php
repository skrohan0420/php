<!DOCTYPE html>
<html>
<head>
	<title>3rd</title>
</head>
<body>
<center>
<h1>First Page</h1>
<br>
<br>
<table>
	<tr>
		<td>
			<a href="<?php echo base_url().'index.php/Mycontroller/second'?>"><img src="<?php echo base_url();?>image/img2.jpg" hight=400 width=400></a>
<br>
			<center>Photo 2</center>
		</td>
		<td>
			<a href="<?php echo base_url().'index.php/Mycontroller/third'?>"><img src="<?php echo base_url();?>image/img3.jpg" hight=400 width=400></a>
<br>
			<center>Photo 3</center>
		</td>
	</tr>
</table>
</center>
</body>
</html>