<!DOCTYPE html>
<html>
<head>
	<title>abc</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/style.css">
</head>
<body bgcolor="orange">
<h1>This is my 1st page</h1>
<p style="color:red;">This is codeigniter</p>
<br>
<br>
<a href="<?php echo base_url().'index.php/Mycontroller/second'?>">Click 2</a>
<br>
<a href="<?php echo base_url().'index.php/Mycontroller/third'?>">Click 3</a>
<br>
<br>

<img src="<?php echo base_url();?>image/Shubhrajit Roy.jpg" hight='100' width='100'><br>
<br>
<a href="<?php echo base_url().'index.php/Mycontroller/second'?>"><img src="<?php echo base_url();?>image/Shubhrajit Roy.jpg" hight='100' width='100'></a>
<style type="text/css">

	body
{
	background-image: url('<?php echo base_url();?>image/img3.jpg');
</style>
</body>
</html>