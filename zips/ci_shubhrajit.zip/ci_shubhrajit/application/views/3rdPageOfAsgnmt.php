<!DOCTYPE html>
<html>
<head>
	<title>3rd</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'css/styl.css'?>">
</head>
<body>
<center>
<h1>Third Page</h1>
<br>
<br>
<table>
	<tr>
		<td colspan="2">
			<a href="<?php echo base_url().'index.php/Mycontroller/first'?>"><img src="<?php echo base_url();?>image/img1.jpg" hight=400 width=400></a>
<br>
			<center>Photo 1</center>
		</td>
	</tr>
</table>
</center>
</body>
</html>