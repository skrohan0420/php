<!DOCTYPE html>
<html>
<head>
	<title>abc</title>
</head>
<body bgcolor="orange">
<h1>This is my 3rd Page</h1>
This is codeigniter

<a href="<?php echo base_url().'index.php/Mycontroller/first'?>">Home</a>

</body>
</html>