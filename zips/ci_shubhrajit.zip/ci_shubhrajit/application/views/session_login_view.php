<!DOCTYPE html>
<html>
<head>
	<title>login</title>
</head>
<body bgcolor="orange">
<center>
	<h1>Login Page</h1>
	<form method="post" autocomplete="off">
		Email:
		<br>
		<input type="text" name="myemail" ><br>
		Password:
		<br>
		<input type="password" name="mypassword">
		<br>
		<br>
		<center>
			<input type="submit" name="submit" value="login">
		</center>
	</form>
</center>
</body>
</html>