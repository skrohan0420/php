<h1>Welcome to facebook</h1>
<a href="<?php echo $this->facebook->login_url();?>">Login with Facebook</a>