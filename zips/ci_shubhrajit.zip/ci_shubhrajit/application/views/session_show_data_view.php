<?php 



foreach ($res as $re) {

	echo $re->name;

}


 ?>