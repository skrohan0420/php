<!DOCTYPE html>
<html>
<head>
	<title>abc</title>
</head>
<body>
<form method="post">
	item name:<input type="text" name="in"><br>
	quantity<input type="text" name="quantity"><br>
	price<input type="text" name="price"><br>
	<input type="submit" name="submit" value="paypal">
</form>
</body>
</html>