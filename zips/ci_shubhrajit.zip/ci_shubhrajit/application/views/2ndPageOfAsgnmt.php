<!DOCTYPE html>
<html>
<head>
	<title>3rd</title>
</head>
<body>
<center>
<h1>Second Page</h1>
<br>
<br>
<table>
	<tr>
		<td>
			<a href="<?php echo base_url().'index.php/Mycontroller/first'?>"><img src="<?php echo base_url();?>image/img1.jpg" hight=400 width=400></a>
<br>
			<center>Photo 1</center>
		</td>
		<td>
			<a href="<?php echo base_url().'index.php/Mycontroller/third'?>"><img src="<?php echo base_url();?>image/img3.jpg" hight=400 width=400></a>
<br>
			<center>Photo 3</center>
		</td>
	</tr>
</table>
</center>
</body>
</html>