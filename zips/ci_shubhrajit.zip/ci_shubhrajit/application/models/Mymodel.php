<?php
class Mymodel extends CI_Model
{
	function freefire()
	{
		echo "This is model class";
	}
}


?>