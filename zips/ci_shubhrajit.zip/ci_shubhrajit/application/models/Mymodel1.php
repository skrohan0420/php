<?php
class Mymodel1 extends CI_Model
{
	function pubg()
	{
		echo "This is another model class ";
	}
}


?>