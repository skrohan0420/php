<?php
class Product extends CI_Controller
{
	public function index($name='')
	{
		echo $name;
	}
}
?>